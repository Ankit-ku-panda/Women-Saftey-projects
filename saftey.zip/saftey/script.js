const API = "http://localhost:5000/api";
let token = "";

function signup() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  fetch(`${API}/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password })
  }).then(res => res.json())
    .then(data => alert("Signup successful! Please login."));
}

function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  fetch(`${API}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  }).then(res => res.json())
    .then(data => {
      token = data.token;
      document.getElementById("auth").style.display = "none";
      document.getElementById("main").style.display = "block";
      loadContacts();
    });
}

function addContact() {
  const contact = document.getElementById("contactEmail").value;
  fetch(`${API}/auth/login`, { // Update contact to DB manually for now
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({})
  }); // (or you update user.contacts manually from MongoDB Compass)
  alert("Contact added (simulated). Add DB route later if needed.");
  loadContacts();
}

function loadContacts() {
  const list = document.getElementById("contactsList");
  list.innerHTML = `<li>Contacts loaded from DB manually or add route.</li>`;
}

function sendSOS() {
  navigator.geolocation.getCurrentPosition(async (pos) => {
    const location = `https://maps.google.com/?q=${pos.coords.latitude},${pos.coords.longitude}`;
    const res = await fetch(`${API}/sos/send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ location })
    });
    const data = await res.json();
    document.getElementById("status").innerText = data.message;
  });
}
